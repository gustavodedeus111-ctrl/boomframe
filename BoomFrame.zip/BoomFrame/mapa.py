from ursina import *
from random import uniform

class Mapa:
    def __init__(self):
        self.blocos = []
        self.direcoes = []

        self.criar_chao()
        self.criar_objetos()

    def criar_chao(self):
        self.chao = Entity(
            model='plane',
            texture='grass',
            collider='mesh',
            scale=(300, 1, 300)
        )

    def criar_objetos(self):
        self.caixa = Entity(
            model='cube',
            texture='brick',
            collider='box',
            position=(15, 0.5, 5),
            scale=(20, 6, 0.4)
        )
        self.caixa = Entity(
            model='cube',
            texture='brick',
            collider='box',
            position=(149, 0.5, 0),
            scale=(0.8, 20, 305)
        )
        self.caixa = Entity(
            model='cube',
            texture='brick',
            collider='box',
            position=(-149, 0.5, 0),
            scale=(0.8, 20, 305)
        )
        self.caixa = Entity(
            model='cube',
            texture='brick',
            collider='box',
            position=(0, 0.5, 149),
            scale=(305, 20, 0.8)
        )
        self.caixa = Entity(
            model='cube',
            texture='brick',
            collider='box',
            position=(0, 0.5, -149),
            scale=(305, 20, 0.8)
        )


        self.bola = Entity(
            model='sphere',
            color=color.red,
            collider='sphere',
            position=(5, 0.5, 10)
        )

        #arvores

        Entity(
        model='assets/arvore.glb',
        position=(10, 0, 15),
        scale=0.5,
        collider='mesh'
        
)