from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController 
from random import uniform 
from panda3d.core import CardMaker, TransparencyAttrib
from mapa import Mapa

app = Ursina()

# Configuração do jogador
jogador = FirstPersonController(collider='box')  
jogador.cursor.visible = False 

mapa = Mapa()

# Configuração do céu
ceu = Sky()

# Configurar uma arma para o jogador
arma = Entity(
    model='assets/AK47.obj',
    scale=0.01,
    position=(0.6, -0.6, 1.5),
    rotation=(0, -70, 5),
    parent=camera.ui,
    texture='assets/color.tga',
    normal_map='assets/normal.tga',
    specular_map='assets/specular.tga'
)

# === A MIRA É ADICIONADA AQUI ===
mira = Entity(
    model='quad',
    parent=camera.ui,
    color=color.white,
    position=(0, 0, 0),
    scale=0.005, # Ajuste para o tamanho desejado
    always_on_top=True
)

#====================================

velocidade_normal = 7
velocidade_corrida = 16
jogador.jump_height = 3
jogador.gravity = 1

def input(key):
    if key == 'left shift' and held_keys['w']:
        jogador.speed = velocidade_corrida

    if key == 'left shift up':
        jogador.speed = velocidade_normal



# =================================
# Criar função de disparo
def disparar():
    posicao_inicial = camera.ui.get_position(relative_to=scene) + Vec3(0.9, -0.5, 0)
    direcao_disparo = camera.forward.normalized()
    projétil = Entity(
        model='sphere',
        color=color.yellow,
        scale=1,
        position=posicao_inicial,
        collider='box',
        always_on_top=True
    )
    projétil.animate_position(
        projétil.position + direcao_disparo * 50,
        duration=0.2,
        curve=curve.linear
    )
    destroy(projétil, delay=1)


arma = Entity(
    parent=camera.ui,      # preso à câmera (FPS)
    model='quad',
    texture='assets/arma.png',
    scale=(2, 0.5),    # ajuste ao gosto
    position=(0.80, -0.70),
    rotation=(0, 0, 70),
    color=color.white,
    always_on_top=True
)




app.run()